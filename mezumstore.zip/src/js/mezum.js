// Logic for MezumStore
// (Create Mezum Object) window.mezum = new Object();
window.mezum = new Object();
// Update Theme Based on Color Picker
const mezum_updateTheme = function($f7 = window.app.f7) {
  window.mezum.themeKeys = Object.values($f7.utils.colorThemeCSSProperties(window.mezum.colorpicker.value.hex));
  window.mezum.themeString = "--f7-theme-color: " + window.mezum.themeKeys[0] + ";--f7-theme-color-rgb:" + window.mezum.themeKeys[1] + ";--f7-theme-color-shade:" + window.mezum.themeKeys[2] + ";--f7-theme-color-tint:" + window.mezum.themeKeys[2] + ";";
  document.querySelector(':root').setAttribute("style", window.mezum.themeString);
  window.localStorage.setItem("themeHex", window.mezum.colorpicker.value.hex);
}
// Update Theme Based on Local Storage
const mezum_updateThemeFromLocalStorage = function($f7 = window.app.f7) {
  window.mezum.themeKeys = Object.values($f7.utils.colorThemeCSSProperties(window.localStorage.getItem("themeHex") || "#f700ce"));
  window.mezum.themeString = "--f7-theme-color: " + window.mezum.themeKeys[0] + ";--f7-theme-color-rgb:" + window.mezum.themeKeys[1] + ";--f7-theme-color-shade:" + window.mezum.themeKeys[2] + ";--f7-theme-color-tint:" + window.mezum.themeKeys[2] + ";";
  document.querySelector(':root').setAttribute("style", window.mezum.themeString);
}
