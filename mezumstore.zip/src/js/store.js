import { createStore, request } from 'framework7';

const store = createStore({
  state: {
    products: []
  },
  getters: {
    products({ state }) {
      return state.products;
    }
  },
  actions: {
    addProduct({ state }, product) {
      state.products = [...state.products, product];
    },
	clearProducts({ state }) {
      state.products = [];
	  console.log("Cleared Store");
    },
  },
});

request.json('https://mezumdata.damotheryeeter1.repl.co/api/apps').then(function (res) {
              let obj = res.data;
			  obj.forEach(function(item, index, array){
				console.log(array[index].id.toString());
				console.log(array[index]);
				store.dispatch('addProduct', {
				  id: mezum_random(15).toString(),
				  title: array[index].title.toString(),
				  description: array[index].description.toString(),
				  plist: array[index].plist.toString(),
				  icon: array[index].icon || "assets/icons/" + array[index].title.toString().toLowerCase() + ".png"
				});
			  });
			  console.log(res.data);
            });

const mezum_random = (length = 8) => {
    return Math.random().toString(16).substr(2, length);
};


export default store;
